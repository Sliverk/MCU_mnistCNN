// tvm target: c -keys=arm_cpu,cpu -device=arm_cpu -mcpu=cortex-m7
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>


#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <arm_acle.h>

#include <tvm/runtime/crt/error_codes.h>


#ifndef ARM_CPU_INTRINSICS_EXIST
#define ARM_CPU_INTRINSICS_EXIST
__attribute__((always_inline)) uint32_t __ror(uint32_t op1, uint32_t op2)
{
  op2 %= 32U;
  if (op2 == 0U)
  {
    return op1;
  }
  return (op1 >> op2) | (op1 << (32U - op2));
}

#define __pkhbt(ARG1,ARG2,ARG3) __extension__ ({                            uint32_t __RES, __ARG1 = (ARG1), __ARG2 = (ARG2);   __asm("pkhbt %0, %1, %2, lsl %3" : "=r" (__RES) :  "r" (__ARG1), "r" (__ARG2), "I" (ARG3)  );   __RES;  })

#define __pkhtb(ARG1,ARG2,ARG3) __extension__ ({                            uint32_t __RES, __ARG1 = (ARG1), __ARG2 = (ARG2);   if (ARG3 == 0)     __asm("pkhtb %0, %1, %2" : "=r" (__RES) :  "r" (__ARG1), "r" (__ARG2)  );   else     __asm("pkhtb %0, %1, %2, asr %3" : "=r" (__RES) :  "r" (__ARG1), "r" (__ARG2), "I" (ARG3)  );   __RES;  })
#endif

#ifndef ARM_CPU_MPROFILE_READ_AND_PAD_EXISTS
#define ARM_CPU_MPROFILE_READ_AND_PAD_EXISTS
__attribute__((always_inline)) static inline const int8_t *read_and_pad(const int8_t *source, int32_t *out1, int32_t *out2)
{
    int32_t inA;
    memcpy(&inA, source, 4);
    source += 4;

    int32_t inAbuf1 = __sxtb16(__ror((uint32_t)inA, 8));
    int32_t inAbuf2 = __sxtb16(inA);
    *out2 = (int32_t)(__pkhtb(inAbuf1, inAbuf2, 16));
    *out1 = (int32_t)(__pkhbt(inAbuf2, inAbuf1, 16));

    return source;
}
#endif



#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1_body_rest_XDPGNFLF(
    int32_t K_arg,
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int K = K_arg;
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int k_base = (K / 4) * 4;
  switch ( K % 4 ) {
  case 1:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] = (int32_t) a_ptr[0] * (int32_t) b_ptr[0];
      }
    }
    break;
  case 2:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] =   (int32_t) a_ptr[0] * (int32_t) b_ptr[0]
                               + (int32_t) a_ptr[1] * (int32_t) b_ptr[1];
      }
    }
    break;
  case 3:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] =   (int32_t) a_ptr[0] * (int32_t) b_ptr[0]
                               + (int32_t) a_ptr[1] * (int32_t) b_ptr[1]
                               + (int32_t) a_ptr[2] * (int32_t) b_ptr[2];
      }
    }
    break;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1x1_body_loop_XDPGNFLF(
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;


  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t sum = 0;
      for (int l = 0; l < 1; l++) {
        sum += (int32_t) aa[i*A_stride + l] * (int32_t) bb[j*B_stride + l];
      }
      // NOTE: this is the line where `*_body` differs from `*_update`. here
      // we're *setting* the result, instead of accumulating, because we know
      // the `i` and `j` itervars span their entire respective axes.
      cc[i*C_stride + j] = sum;
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1x1_body_XDPGNFLF(
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int16_t bb_pad[1];
  int32_t retcode = 0;

  if ( 1 < 2 && 1 < 2 ) {
    retcode = gemm_1x1x1_body_loop_XDPGNFLF(aa, bb, cc, A_stride, B_stride, C_stride);
    goto out;
  }

  for (int i = 0; i < 1; i++)
    for (int j = 0; j < 1 / 4; j++)
      read_and_pad(&bb[i*B_stride + j*4], (int32_t*) &bb_pad[i*1 + j*4], (int32_t*) &bb_pad[i*1 + j*4 + 2]);

  for (int i = 0; i < 1; i++) {
    int16_t aa_pad_line[1];
    for (int l = 0; l < 1 / 4; l++)
      read_and_pad(&aa[i*A_stride + l*4], (int32_t*) &aa_pad_line[l*4], (int32_t*) &aa_pad_line[l*4 + 2]);

    for (int j = 0; j < 1; j++) {
      int32_t *aa_ptr = (int32_t *) aa_pad_line;
      int32_t *bb_ptr = (int32_t *) &bb_pad[j*1];
      int32_t sum = 0;
      for (int l = 0; l < 2 * (1 / 4); l++) {
        sum = __smlad(*aa_ptr, *bb_ptr, sum);
        ++ aa_ptr; ++ bb_ptr;
      }
      // NOTE: this is the line where `*_body` differs from `*_update`. here
      // we're *setting* the result, instead of accumulating, because we know
      // the `i` and `j` itervars span their entire respective axes.
      cc[i*C_stride + j] = sum;
    }
  }

  if ( 1 % 4 != 0 )
    gemm_1x1_body_rest_XDPGNFLF(1, aa, bb, cc, A_stride, B_stride, C_stride);

out:
  return retcode;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1_update_rest_XDPGNFLF(
    int32_t K_arg,
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int K = K_arg;
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int k_base = (K / 4) * 4;
  switch ( K % 4 ) {
  case 1:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] += (int32_t) a_ptr[0] * (int32_t) b_ptr[0];
      }
    }
    break;
  case 2:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] +=   (int32_t) a_ptr[0] * (int32_t) b_ptr[0]
                                + (int32_t) a_ptr[1] * (int32_t) b_ptr[1];
      }
    }
    break;
  case 3:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] +=   (int32_t) a_ptr[0] * (int32_t) b_ptr[0]
                                + (int32_t) a_ptr[1] * (int32_t) b_ptr[1]
                                + (int32_t) a_ptr[2] * (int32_t) b_ptr[2];
      }
    }
    break;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1x1_update_loop_XDPGNFLF(
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t sum = 0;
      for (int l = 0; l < 1; l++) {
        sum += (int32_t) aa[i*A_stride + l] * (int32_t) bb[j*B_stride + l];
      }
      cc[i*C_stride + j] += sum;
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1x1_update_XDPGNFLF(
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int16_t bb_pad[1];
  int32_t retcode = 0;

  if ( 1 < 2 && 1 < 2 ) {
    retcode = gemm_1x1x1_update_loop_XDPGNFLF(aa, bb, cc, A_stride, B_stride, C_stride);
    goto out;
  }

  for (int i = 0; i < 1; i++)
    for (int j = 0; j < 1 / 4; j++)
      read_and_pad(&bb[i*B_stride + j*4], (int32_t*) &bb_pad[i*1 + j*4], (int32_t*) &bb_pad[i*1 + j*4 + 2]);

  for (int i = 0; i < 1; i++) {
    int16_t aa_pad_line[1];
    for (int l = 0; l < 1 / 4; l++)
      read_and_pad(&aa[i*A_stride + l*4], (int32_t*) &aa_pad_line[l*4], (int32_t*) &aa_pad_line[l*4 + 2]);

    for (int j = 0; j < 1; j++) {
      int32_t *aa_ptr = (int32_t *) aa_pad_line;
      int32_t *bb_ptr = (int32_t *) &bb_pad[j*1];
      int32_t sum = 0;
      for (int l = 0; l < 2 * (1 / 4); l++) {
        sum = __smlad(*aa_ptr, *bb_ptr, sum);
        ++ aa_ptr; ++ bb_ptr;
      }
      cc[i*C_stride + j] += sum;
    }
  }

  if ( 1 % 4 != 0 )
    gemm_1x1_update_rest_XDPGNFLF(1, aa, bb, cc, A_stride, B_stride, C_stride);

out:
  return retcode;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1_body_rest_XDPGNFLF(
    int32_t K_arg,
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int K = K_arg;
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int k_base = (K / 2) * 2;
  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int16_t *a_ptr = &aa[i * A_stride + k_base];
      int16_t *b_ptr = &bb[j * B_stride + k_base];
      cc[i * C_stride + j] = (int32_t) a_ptr[0] * (int32_t) b_ptr[0];
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1x1_body_loop_XDPGNFLF(
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t sum = 0;
      for (int l = 0; l < 1; l++) {
        sum += (int32_t) aa[i*A_stride + l] * (int32_t) bb[j*B_stride + l];
      }
      // NOTE: this is the line where `*_body` differs from `*_update`. here
      // we're *setting* the result, instead of accumulating, because we know
      // the `i` and `j` itervars span their entire respective axes.
      cc[i*C_stride + j] = sum;
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1x1_body_XDPGNFLF(
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int32_t retcode = 0;

  if ( 1 < 2 && 1 < 2 ) {
    retcode = gemm16_1x1x1_body_loop_XDPGNFLF(aa, bb, cc, A_stride, B_stride, C_stride);
    goto out;
  }

  if(((uint32_t)aa & 0x3) != 0 || ((uint32_t)bb & 0x3) != 0){
    retcode = kTvmErrorFunctionCallInvalidArg;
    goto out;
  }

  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t aa_vector[1 / 2];
      int32_t bb_vector[1 / 2];
      memcpy(&aa_vector, &aa[i * A_stride], sizeof(aa_vector));
      memcpy(&bb_vector, &bb[j * B_stride], sizeof(bb_vector));

      int32_t sum = 0;
      for (int l = 0; l < 1 / 2; l++) {
        sum = __smlad(aa_vector[l], bb_vector[l], sum);
      }
      // NOTE: this is the line where `*_body` differs from `*_update`. here
      // we're *setting* the result, instead of accumulating, because we know
      // the `i` and `j` itervars span their entire respective axes.
      cc[i*C_stride + j] = sum;
    }
  }

  if ( 1 % 2 != 0 )
    gemm16_1x1_body_rest_XDPGNFLF(1, aa, bb, cc, A_stride, B_stride, C_stride);

out:
  return retcode;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1_update_rest_XDPGNFLF(
    int32_t K_arg,
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int K = K_arg;
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int k_base = (K / 2) * 2;
  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int16_t *a_ptr = &aa[i * A_stride + k_base];
      int16_t *b_ptr = &bb[j * B_stride + k_base];
      cc[i * C_stride + j] += (int32_t) a_ptr[0] * (int32_t) b_ptr[0];
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1x1_update_loop_XDPGNFLF(
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t sum = 0;
      for (int l = 0; l < 1; l++) {
        sum += (int32_t) aa[i*A_stride + l] * (int32_t) bb[j*B_stride + l];
      }
      cc[i*C_stride + j] += sum;
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1x1_update_XDPGNFLF(
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int32_t retcode = 0;

  if ( 1 < 2 && 1 < 2 ) {
    retcode = gemm16_1x1x1_update_loop_XDPGNFLF(aa, bb, cc, A_stride, B_stride, C_stride);
    goto out;
  }

  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t aa_vector[1 / 2];
      int32_t bb_vector[1 / 2];
      memcpy(&aa_vector, &aa[i * A_stride], sizeof(aa_vector));
      memcpy(&bb_vector, &bb[j * B_stride], sizeof(bb_vector));

      int32_t sum = 0;
      for (int l = 0; l < 1 / 2; l++) {
        sum = __smlad(aa_vector[l], bb_vector[l], sum);
      }
      cc[i*C_stride + j] += sum;
    }
  }

  if ( 1 % 2 != 0 )
    gemm16_1x1_update_rest_XDPGNFLF(1, aa, bb, cc, A_stride, B_stride, C_stride);

out:
  return retcode;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1x1_reset_XDPGNFLF(int32_t *cc, int32_t C_stride) {
  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      cc[i*C_stride + j] = 0;
    }
  }
  return 0;
}



#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <arm_acle.h>

#include <tvm/runtime/crt/error_codes.h>


#ifndef ARM_CPU_INTRINSICS_EXIST
#define ARM_CPU_INTRINSICS_EXIST
__attribute__((always_inline)) uint32_t __ror(uint32_t op1, uint32_t op2)
{
  op2 %= 32U;
  if (op2 == 0U)
  {
    return op1;
  }
  return (op1 >> op2) | (op1 << (32U - op2));
}

#define __pkhbt(ARG1,ARG2,ARG3) __extension__ ({                            uint32_t __RES, __ARG1 = (ARG1), __ARG2 = (ARG2);   __asm("pkhbt %0, %1, %2, lsl %3" : "=r" (__RES) :  "r" (__ARG1), "r" (__ARG2), "I" (ARG3)  );   __RES;  })

#define __pkhtb(ARG1,ARG2,ARG3) __extension__ ({                            uint32_t __RES, __ARG1 = (ARG1), __ARG2 = (ARG2);   if (ARG3 == 0)     __asm("pkhtb %0, %1, %2" : "=r" (__RES) :  "r" (__ARG1), "r" (__ARG2)  );   else     __asm("pkhtb %0, %1, %2, asr %3" : "=r" (__RES) :  "r" (__ARG1), "r" (__ARG2), "I" (ARG3)  );   __RES;  })
#endif

#ifndef ARM_CPU_MPROFILE_READ_AND_PAD_EXISTS
#define ARM_CPU_MPROFILE_READ_AND_PAD_EXISTS
__attribute__((always_inline)) static inline const int8_t *read_and_pad(const int8_t *source, int32_t *out1, int32_t *out2)
{
    int32_t inA;
    memcpy(&inA, source, 4);
    source += 4;

    int32_t inAbuf1 = __sxtb16(__ror((uint32_t)inA, 8));
    int32_t inAbuf2 = __sxtb16(inA);
    *out2 = (int32_t)(__pkhtb(inAbuf1, inAbuf2, 16));
    *out1 = (int32_t)(__pkhbt(inAbuf2, inAbuf1, 16));

    return source;
}
#endif



#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1_body_rest_BNVCGIOM(
    int32_t K_arg,
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int K = K_arg;
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int k_base = (K / 4) * 4;
  switch ( K % 4 ) {
  case 1:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] = (int32_t) a_ptr[0] * (int32_t) b_ptr[0];
      }
    }
    break;
  case 2:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] =   (int32_t) a_ptr[0] * (int32_t) b_ptr[0]
                               + (int32_t) a_ptr[1] * (int32_t) b_ptr[1];
      }
    }
    break;
  case 3:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] =   (int32_t) a_ptr[0] * (int32_t) b_ptr[0]
                               + (int32_t) a_ptr[1] * (int32_t) b_ptr[1]
                               + (int32_t) a_ptr[2] * (int32_t) b_ptr[2];
      }
    }
    break;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1x1_body_loop_BNVCGIOM(
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;


  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t sum = 0;
      for (int l = 0; l < 1; l++) {
        sum += (int32_t) aa[i*A_stride + l] * (int32_t) bb[j*B_stride + l];
      }
      // NOTE: this is the line where `*_body` differs from `*_update`. here
      // we're *setting* the result, instead of accumulating, because we know
      // the `i` and `j` itervars span their entire respective axes.
      cc[i*C_stride + j] = sum;
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1x1_body_BNVCGIOM(
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int16_t bb_pad[1];
  int32_t retcode = 0;

  if ( 1 < 2 && 1 < 2 ) {
    retcode = gemm_1x1x1_body_loop_BNVCGIOM(aa, bb, cc, A_stride, B_stride, C_stride);
    goto out;
  }

  for (int i = 0; i < 1; i++)
    for (int j = 0; j < 1 / 4; j++)
      read_and_pad(&bb[i*B_stride + j*4], (int32_t*) &bb_pad[i*1 + j*4], (int32_t*) &bb_pad[i*1 + j*4 + 2]);

  for (int i = 0; i < 1; i++) {
    int16_t aa_pad_line[1];
    for (int l = 0; l < 1 / 4; l++)
      read_and_pad(&aa[i*A_stride + l*4], (int32_t*) &aa_pad_line[l*4], (int32_t*) &aa_pad_line[l*4 + 2]);

    for (int j = 0; j < 1; j++) {
      int32_t *aa_ptr = (int32_t *) aa_pad_line;
      int32_t *bb_ptr = (int32_t *) &bb_pad[j*1];
      int32_t sum = 0;
      for (int l = 0; l < 2 * (1 / 4); l++) {
        sum = __smlad(*aa_ptr, *bb_ptr, sum);
        ++ aa_ptr; ++ bb_ptr;
      }
      // NOTE: this is the line where `*_body` differs from `*_update`. here
      // we're *setting* the result, instead of accumulating, because we know
      // the `i` and `j` itervars span their entire respective axes.
      cc[i*C_stride + j] = sum;
    }
  }

  if ( 1 % 4 != 0 )
    gemm_1x1_body_rest_BNVCGIOM(1, aa, bb, cc, A_stride, B_stride, C_stride);

out:
  return retcode;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1_update_rest_BNVCGIOM(
    int32_t K_arg,
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int K = K_arg;
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int k_base = (K / 4) * 4;
  switch ( K % 4 ) {
  case 1:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] += (int32_t) a_ptr[0] * (int32_t) b_ptr[0];
      }
    }
    break;
  case 2:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] +=   (int32_t) a_ptr[0] * (int32_t) b_ptr[0]
                                + (int32_t) a_ptr[1] * (int32_t) b_ptr[1];
      }
    }
    break;
  case 3:
    for (int i = 0; i < 1; i++) {
      for (int j = 0; j < 1; j++) {
        int8_t *a_ptr = &aa[i * A_stride + k_base];
        int8_t *b_ptr = &bb[j * B_stride + k_base];
        cc[i * C_stride + j] +=   (int32_t) a_ptr[0] * (int32_t) b_ptr[0]
                                + (int32_t) a_ptr[1] * (int32_t) b_ptr[1]
                                + (int32_t) a_ptr[2] * (int32_t) b_ptr[2];
      }
    }
    break;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1x1_update_loop_BNVCGIOM(
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t sum = 0;
      for (int l = 0; l < 1; l++) {
        sum += (int32_t) aa[i*A_stride + l] * (int32_t) bb[j*B_stride + l];
      }
      cc[i*C_stride + j] += sum;
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1x1_update_BNVCGIOM(
    int8_t *aa, int8_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int16_t bb_pad[1];
  int32_t retcode = 0;

  if ( 1 < 2 && 1 < 2 ) {
    retcode = gemm_1x1x1_update_loop_BNVCGIOM(aa, bb, cc, A_stride, B_stride, C_stride);
    goto out;
  }

  for (int i = 0; i < 1; i++)
    for (int j = 0; j < 1 / 4; j++)
      read_and_pad(&bb[i*B_stride + j*4], (int32_t*) &bb_pad[i*1 + j*4], (int32_t*) &bb_pad[i*1 + j*4 + 2]);

  for (int i = 0; i < 1; i++) {
    int16_t aa_pad_line[1];
    for (int l = 0; l < 1 / 4; l++)
      read_and_pad(&aa[i*A_stride + l*4], (int32_t*) &aa_pad_line[l*4], (int32_t*) &aa_pad_line[l*4 + 2]);

    for (int j = 0; j < 1; j++) {
      int32_t *aa_ptr = (int32_t *) aa_pad_line;
      int32_t *bb_ptr = (int32_t *) &bb_pad[j*1];
      int32_t sum = 0;
      for (int l = 0; l < 2 * (1 / 4); l++) {
        sum = __smlad(*aa_ptr, *bb_ptr, sum);
        ++ aa_ptr; ++ bb_ptr;
      }
      cc[i*C_stride + j] += sum;
    }
  }

  if ( 1 % 4 != 0 )
    gemm_1x1_update_rest_BNVCGIOM(1, aa, bb, cc, A_stride, B_stride, C_stride);

out:
  return retcode;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1_body_rest_BNVCGIOM(
    int32_t K_arg,
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int K = K_arg;
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int k_base = (K / 2) * 2;
  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int16_t *a_ptr = &aa[i * A_stride + k_base];
      int16_t *b_ptr = &bb[j * B_stride + k_base];
      cc[i * C_stride + j] = (int32_t) a_ptr[0] * (int32_t) b_ptr[0];
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1x1_body_loop_BNVCGIOM(
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t sum = 0;
      for (int l = 0; l < 1; l++) {
        sum += (int32_t) aa[i*A_stride + l] * (int32_t) bb[j*B_stride + l];
      }
      // NOTE: this is the line where `*_body` differs from `*_update`. here
      // we're *setting* the result, instead of accumulating, because we know
      // the `i` and `j` itervars span their entire respective axes.
      cc[i*C_stride + j] = sum;
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1x1_body_BNVCGIOM(
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int32_t retcode = 0;

  if ( 1 < 2 && 1 < 2 ) {
    retcode = gemm16_1x1x1_body_loop_BNVCGIOM(aa, bb, cc, A_stride, B_stride, C_stride);
    goto out;
  }

  if(((uint32_t)aa & 0x3) != 0 || ((uint32_t)bb & 0x3) != 0){
    retcode = kTvmErrorFunctionCallInvalidArg;
    goto out;
  }

  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t aa_vector[1 / 2];
      int32_t bb_vector[1 / 2];
      memcpy(&aa_vector, &aa[i * A_stride], sizeof(aa_vector));
      memcpy(&bb_vector, &bb[j * B_stride], sizeof(bb_vector));

      int32_t sum = 0;
      for (int l = 0; l < 1 / 2; l++) {
        sum = __smlad(aa_vector[l], bb_vector[l], sum);
      }
      // NOTE: this is the line where `*_body` differs from `*_update`. here
      // we're *setting* the result, instead of accumulating, because we know
      // the `i` and `j` itervars span their entire respective axes.
      cc[i*C_stride + j] = sum;
    }
  }

  if ( 1 % 2 != 0 )
    gemm16_1x1_body_rest_BNVCGIOM(1, aa, bb, cc, A_stride, B_stride, C_stride);

out:
  return retcode;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1_update_rest_BNVCGIOM(
    int32_t K_arg,
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int K = K_arg;
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int k_base = (K / 2) * 2;
  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int16_t *a_ptr = &aa[i * A_stride + k_base];
      int16_t *b_ptr = &bb[j * B_stride + k_base];
      cc[i * C_stride + j] += (int32_t) a_ptr[0] * (int32_t) b_ptr[0];
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1x1_update_loop_BNVCGIOM(
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t sum = 0;
      for (int l = 0; l < 1; l++) {
        sum += (int32_t) aa[i*A_stride + l] * (int32_t) bb[j*B_stride + l];
      }
      cc[i*C_stride + j] += sum;
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm16_1x1x1_update_BNVCGIOM(
    int16_t *aa, int16_t *bb, int32_t *cc,
    int32_t A_stride_arg, int32_t B_stride_arg, int32_t C_stride_arg) {
  int A_stride = A_stride_arg;
  int B_stride = B_stride_arg;
  int C_stride = C_stride_arg;

  int32_t retcode = 0;

  if ( 1 < 2 && 1 < 2 ) {
    retcode = gemm16_1x1x1_update_loop_BNVCGIOM(aa, bb, cc, A_stride, B_stride, C_stride);
    goto out;
  }

  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      int32_t aa_vector[1 / 2];
      int32_t bb_vector[1 / 2];
      memcpy(&aa_vector, &aa[i * A_stride], sizeof(aa_vector));
      memcpy(&bb_vector, &bb[j * B_stride], sizeof(bb_vector));

      int32_t sum = 0;
      for (int l = 0; l < 1 / 2; l++) {
        sum = __smlad(aa_vector[l], bb_vector[l], sum);
      }
      cc[i*C_stride + j] += sum;
    }
  }

  if ( 1 % 2 != 0 )
    gemm16_1x1_update_rest_BNVCGIOM(1, aa, bb, cc, A_stride, B_stride, C_stride);

out:
  return retcode;
}

#ifdef __cplusplus
extern "C"
#endif
__attribute__((always_inline)) static inline int32_t gemm_1x1x1_reset_BNVCGIOM(int32_t *cc, int32_t C_stride) {
  for (int i = 0; i < 1; i++) {
    for (int j = 0; j < 1; j++) {
      cc[i*C_stride + j] = 0;
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_divide_round_add_clip_cast_nn_pad_cast_add_cast(float* p0, int8_t* T_cast, uint8_t* global_const_workspace_2_var, uint8_t* global_workspace_3_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_add_clip_cast(int8_t* p0, uint8_t* T_cast, uint8_t* global_const_workspace_12_var, uint8_t* global_workspace_13_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_clip_cast(int8_t* p0, uint8_t* T_cast, uint8_t* global_const_workspace_4_var, uint8_t* global_workspace_5_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_clip_cast_1(int8_t* p0, uint8_t* T_cast, uint8_t* global_const_workspace_8_var, uint8_t* global_workspace_9_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_dense_add_fixed_point_multiply_clip_add_cast(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_16_var, uint8_t* global_workspace_17_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_dense_subtract_add_fixed_point_multiply_add_clip_subtract_cast_multiply(int8_t* p0, float* T_multiply, uint8_t* global_const_workspace_18_var, uint8_t* global_workspace_19_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_log_softmax(float* p0, float* compute, uint8_t* global_const_workspace_20_var, uint8_t* global_workspace_21_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_max_pool2d_cast_add_cast(uint8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_6_var, uint8_t* global_workspace_7_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_max_pool2d_cast_add_cast_1(uint8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_10_var, uint8_t* global_workspace_11_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_reshape_squeeze_cast_add_cast(uint8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_14_var, uint8_t* global_workspace_15_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* input0_buffer_var, float* output_buffer_var, uint8_t* global_const_workspace_0_var, uint8_t* global_workspace_1_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float roundf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t gemm_1x1x1_reset_XDPGNFLF(int32_t*, int32_t);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t gemm_1x1x1_update_XDPGNFLF(int8_t*, int8_t*, int32_t*, int32_t, int32_t, int32_t);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t gemm_1x1x1_reset_BNVCGIOM(int32_t*, int32_t);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t gemm_1x1x1_update_BNVCGIOM(int8_t*, int8_t*, int32_t*, int32_t, int32_t, int32_t);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float expf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float logf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_divide_round_add_clip_cast_nn_pad_cast_add_cast(float* p0, int8_t* T_cast, uint8_t* global_const_workspace_2_var, uint8_t* global_workspace_3_var) {
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 32; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
      for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
        int32_t cse_var_2 = (ax3_outer * 16);
        int32_t cse_var_1 = ((ax3_outer * 8) + (ax3_inner >> 1));
        float v_ = roundf((p0[((((ax0_ax1_fused_ax2_fused * 28) + cse_var_2) + ax3_inner) - 58)] * 7.860388e+01f)) + 3.300000e+01f;
        float v__1 = (v_) < (2.550000e+02f) ? (v_) : (2.550000e+02f);
        T_cast[(((ax0_ax1_fused_ax2_fused * 32) + cse_var_2) + ax3_inner)] = ((int8_t)(((int32_t)(((((2 <= ax0_ax1_fused_ax2_fused) && (ax0_ax1_fused_ax2_fused < 30)) && (1 <= cse_var_1)) && (cse_var_1 < 15)) ? ((uint8_t)((v__1) > (0.000000e+00f) ? (v__1) : (0.000000e+00f))) : (uint8_t)33)) - 128));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_add_clip_cast(int8_t* p0, uint8_t* T_cast, uint8_t* global_const_workspace_12_var, uint8_t* global_workspace_13_var) {
  void* fused_nn_conv2d_constant_2_let = (&(global_const_workspace_12_var[61808]));
  void* fused_nn_conv2d_subtract_constant_2_let = (&(global_const_workspace_12_var[61328]));
  void* fused_constant_2_let = (&(global_const_workspace_12_var[0]));
  void* data_vec_let = (&(global_workspace_13_var[0]));
  for (int32_t ci = 0; ci < 16; ++ci) {
    for (int32_t vh = 0; vh < 5; ++vh) {
      for (int32_t vw = 0; vw < 5; ++vw) {
        int32_t cse_var_1 = (((ci * 25) + (vh * 5)) + vw);
        ((int8_t*)data_vec_let)[cse_var_1] = p0[cse_var_1];
      }
    }
  }
  for (int32_t ax1_outer = 0; ax1_outer < 30; ++ax1_outer) {
    void* conv_let = (&(global_workspace_13_var[520]));
    for (int32_t vc_init = 0; vc_init < 4; ++vc_init) {
      ((int32_t*)conv_let)[vc_init] = 0;
    }
    for (int32_t ci_1 = 0; ci_1 < 16; ++ci_1) {
      for (int32_t kh = 0; kh < 5; ++kh) {
        for (int32_t vc = 0; vc < 4; ++vc) {
          ((int32_t*)conv_let)[vc] = (((int32_t*)conv_let)[vc] + (((int32_t)((int8_t*)data_vec_let)[((ci_1 * 25) + (kh * 5))]) * ((int32_t)((int8_t*)fused_constant_2_let)[((((ax1_outer * 1600) + (ci_1 * 100)) + (kh * 20)) + vc)])));
        }
        for (int32_t vc_1 = 0; vc_1 < 4; ++vc_1) {
          ((int32_t*)conv_let)[vc_1] = (((int32_t*)conv_let)[vc_1] + (((int32_t)((int8_t*)data_vec_let)[(((ci_1 * 25) + (kh * 5)) + 1)]) * ((int32_t)((int8_t*)fused_constant_2_let)[(((((ax1_outer * 1600) + (ci_1 * 100)) + (kh * 20)) + vc_1) + 4)])));
        }
        for (int32_t vc_2 = 0; vc_2 < 4; ++vc_2) {
          ((int32_t*)conv_let)[vc_2] = (((int32_t*)conv_let)[vc_2] + (((int32_t)((int8_t*)data_vec_let)[(((ci_1 * 25) + (kh * 5)) + 2)]) * ((int32_t)((int8_t*)fused_constant_2_let)[(((((ax1_outer * 1600) + (ci_1 * 100)) + (kh * 20)) + vc_2) + 8)])));
        }
        for (int32_t vc_3 = 0; vc_3 < 4; ++vc_3) {
          ((int32_t*)conv_let)[vc_3] = (((int32_t*)conv_let)[vc_3] + (((int32_t)((int8_t*)data_vec_let)[(((ci_1 * 25) + (kh * 5)) + 3)]) * ((int32_t)((int8_t*)fused_constant_2_let)[(((((ax1_outer * 1600) + (ci_1 * 100)) + (kh * 20)) + vc_3) + 12)])));
        }
        for (int32_t vc_4 = 0; vc_4 < 4; ++vc_4) {
          ((int32_t*)conv_let)[vc_4] = (((int32_t*)conv_let)[vc_4] + (((int32_t)((int8_t*)data_vec_let)[(((ci_1 * 25) + (kh * 5)) + 4)]) * ((int32_t)((int8_t*)fused_constant_2_let)[(((((ax1_outer * 1600) + (ci_1 * 100)) + (kh * 20)) + vc_4) + 16)])));
        }
      }
    }
    for (int32_t ax1_inner = 0; ax1_inner < 4; ++ax1_inner) {
      int32_t cse_var_2 = ((ax1_outer * 4) + ax1_inner);
      int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)conv_let)[ax1_inner] + ((int32_t*)fused_nn_conv2d_subtract_constant_2_let)[cse_var_2]) - ((int32_t*)fused_nn_conv2d_constant_2_let)[cse_var_2])) << ((int64_t)0)) : ((int64_t)((((int32_t*)conv_let)[ax1_inner] + ((int32_t*)fused_nn_conv2d_subtract_constant_2_let)[cse_var_2]) - ((int32_t*)fused_nn_conv2d_constant_2_let)[cse_var_2]))) * (int64_t)1644888725) + ((int64_t)1 << ((int64_t)((10 + 31) - 1)))) >> ((int64_t)(10 + 31)))) + 128;
      int32_t v__1 = (v_) < (255) ? (v_) : (255);
      T_cast[cse_var_2] = ((uint8_t)((v__1) > (0) ? (v__1) : (0)));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_clip_cast(int8_t* p0, uint8_t* T_cast, uint8_t* global_const_workspace_4_var, uint8_t* global_workspace_5_var) {
  void* fused_nn_conv2d_constant_let = (&(global_const_workspace_4_var[63040]));
  void* fused_nn_conv2d_subtract_constant_let = (&(global_const_workspace_4_var[63008]));
  void* fused_constant_let = (&(global_const_workspace_4_var[62624]));
  void* data_vec_let = (&(global_workspace_5_var[4704]));
  for (int32_t h = 0; h < 7; ++h) {
    for (int32_t w = 0; w < 4; ++w) {
      for (int32_t vh = 0; vh < 8; ++vh) {
        for (int32_t vw = 0; vw < 11; ++vw) {
          ((int8_t*)data_vec_let)[((((h * 352) + (w * 88)) + (vh * 11)) + vw)] = p0[((((h * 128) + (vh * 32)) + (w * 7)) + vw)];
        }
      }
    }
  }
  for (int32_t ax1_outer = 0; ax1_outer < 2; ++ax1_outer) {
    void* conv_let = (&(global_workspace_5_var[7168]));
    for (int32_t ax2_outer = 0; ax2_outer < 7; ++ax2_outer) {
      for (int32_t ax3_outer = 0; ax3_outer < 4; ++ax3_outer) {
        for (int32_t vw_init = 0; vw_init < 7; ++vw_init) {
          for (int32_t vc_init = 0; vc_init < 3; ++vc_init) {
            ((int32_t*)conv_let)[((vw_init * 3) + vc_init)] = 0;
          }
        }
        for (int32_t vw_init_1 = 0; vw_init_1 < 7; ++vw_init_1) {
          for (int32_t vc_init_1 = 0; vc_init_1 < 3; ++vc_init_1) {
            ((int32_t*)conv_let)[(((vw_init_1 * 3) + vc_init_1) + 21)] = 0;
          }
        }
        for (int32_t vw_init_2 = 0; vw_init_2 < 7; ++vw_init_2) {
          for (int32_t vc_init_2 = 0; vc_init_2 < 3; ++vc_init_2) {
            ((int32_t*)conv_let)[(((vw_init_2 * 3) + vc_init_2) + 42)] = 0;
          }
        }
        for (int32_t vw_init_3 = 0; vw_init_3 < 7; ++vw_init_3) {
          for (int32_t vc_init_3 = 0; vc_init_3 < 3; ++vc_init_3) {
            ((int32_t*)conv_let)[(((vw_init_3 * 3) + vc_init_3) + 63)] = 0;
          }
        }
        for (int32_t kh = 0; kh < 5; ++kh) {
          for (int32_t kw = 0; kw < 5; ++kw) {
            for (int32_t vw_1 = 0; vw_1 < 7; ++vw_1) {
              for (int32_t vc = 0; vc < 3; ++vc) {
                int32_t cse_var_1 = ((vw_1 * 3) + vc);
                ((int32_t*)conv_let)[cse_var_1] = (((int32_t*)conv_let)[cse_var_1] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 352) + (ax3_outer * 88)) + (kh * 11)) + vw_1) + kw)]) * ((int32_t)((int8_t*)fused_constant_let)[((((ax1_outer * 75) + (kh * 15)) + (kw * 3)) + vc)])));
              }
            }
            for (int32_t vw_2 = 0; vw_2 < 7; ++vw_2) {
              for (int32_t vc_1 = 0; vc_1 < 3; ++vc_1) {
                int32_t cse_var_2 = (((vw_2 * 3) + vc_1) + 21);
                ((int32_t*)conv_let)[cse_var_2] = (((int32_t*)conv_let)[cse_var_2] + (((int32_t)((int8_t*)data_vec_let)[((((((ax2_outer * 352) + (ax3_outer * 88)) + (kh * 11)) + vw_2) + kw) + 11)]) * ((int32_t)((int8_t*)fused_constant_let)[((((ax1_outer * 75) + (kh * 15)) + (kw * 3)) + vc_1)])));
              }
            }
            for (int32_t vw_3 = 0; vw_3 < 7; ++vw_3) {
              for (int32_t vc_2 = 0; vc_2 < 3; ++vc_2) {
                int32_t cse_var_3 = (((vw_3 * 3) + vc_2) + 42);
                ((int32_t*)conv_let)[cse_var_3] = (((int32_t*)conv_let)[cse_var_3] + (((int32_t)((int8_t*)data_vec_let)[((((((ax2_outer * 352) + (ax3_outer * 88)) + (kh * 11)) + vw_3) + kw) + 22)]) * ((int32_t)((int8_t*)fused_constant_let)[((((ax1_outer * 75) + (kh * 15)) + (kw * 3)) + vc_2)])));
              }
            }
            for (int32_t vw_4 = 0; vw_4 < 7; ++vw_4) {
              for (int32_t vc_3 = 0; vc_3 < 3; ++vc_3) {
                int32_t cse_var_4 = (((vw_4 * 3) + vc_3) + 63);
                ((int32_t*)conv_let)[cse_var_4] = (((int32_t*)conv_let)[cse_var_4] + (((int32_t)((int8_t*)data_vec_let)[((((((ax2_outer * 352) + (ax3_outer * 88)) + (kh * 11)) + vw_4) + kw) + 33)]) * ((int32_t)((int8_t*)fused_constant_let)[((((ax1_outer * 75) + (kh * 15)) + (kw * 3)) + vc_3)])));
              }
            }
          }
        }
        for (int32_t ax3_inner = 0; ax3_inner < 7; ++ax3_inner) {
          for (int32_t ax1_inner = 0; ax1_inner < 3; ++ax1_inner) {
            int32_t cse_var_5 = ((ax1_outer * 3) + ax1_inner);
            int32_t v_ = (int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)conv_let)[((ax3_inner * 3) + ax1_inner)] + ((int32_t*)fused_nn_conv2d_subtract_constant_let)[cse_var_5]) - ((int32_t*)fused_nn_conv2d_constant_let)[cse_var_5])) << ((int64_t)0)) : ((int64_t)((((int32_t*)conv_let)[((ax3_inner * 3) + ax1_inner)] + ((int32_t*)fused_nn_conv2d_subtract_constant_let)[cse_var_5]) - ((int32_t*)fused_nn_conv2d_constant_let)[cse_var_5]))) * (int64_t)2002065659) + ((int64_t)1 << ((int64_t)((9 + 31) - 1)))) >> ((int64_t)(9 + 31)));
            int32_t v__1 = (v_) < (255) ? (v_) : (255);
            T_cast[(((((ax1_outer * 2352) + (ax1_inner * 784)) + (ax2_outer * 112)) + (ax3_outer * 7)) + ax3_inner)] = ((uint8_t)((v__1) > (0) ? (v__1) : (0)));
          }
        }
        for (int32_t ax3_inner_1 = 0; ax3_inner_1 < 7; ++ax3_inner_1) {
          for (int32_t ax1_inner_1 = 0; ax1_inner_1 < 3; ++ax1_inner_1) {
            int32_t cse_var_6 = ((ax1_outer * 3) + ax1_inner_1);
            int32_t v__2 = (int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)conv_let)[(((ax3_inner_1 * 3) + ax1_inner_1) + 21)] + ((int32_t*)fused_nn_conv2d_subtract_constant_let)[cse_var_6]) - ((int32_t*)fused_nn_conv2d_constant_let)[cse_var_6])) << ((int64_t)0)) : ((int64_t)((((int32_t*)conv_let)[(((ax3_inner_1 * 3) + ax1_inner_1) + 21)] + ((int32_t*)fused_nn_conv2d_subtract_constant_let)[cse_var_6]) - ((int32_t*)fused_nn_conv2d_constant_let)[cse_var_6]))) * (int64_t)2002065659) + ((int64_t)1 << ((int64_t)((9 + 31) - 1)))) >> ((int64_t)(9 + 31)));
            int32_t v__3 = (v__2) < (255) ? (v__2) : (255);
            T_cast[((((((ax1_outer * 2352) + (ax1_inner_1 * 784)) + (ax2_outer * 112)) + (ax3_outer * 7)) + ax3_inner_1) + 28)] = ((uint8_t)((v__3) > (0) ? (v__3) : (0)));
          }
        }
        for (int32_t ax3_inner_2 = 0; ax3_inner_2 < 7; ++ax3_inner_2) {
          for (int32_t ax1_inner_2 = 0; ax1_inner_2 < 3; ++ax1_inner_2) {
            int32_t cse_var_7 = ((ax1_outer * 3) + ax1_inner_2);
            int32_t v__4 = (int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)conv_let)[(((ax3_inner_2 * 3) + ax1_inner_2) + 42)] + ((int32_t*)fused_nn_conv2d_subtract_constant_let)[cse_var_7]) - ((int32_t*)fused_nn_conv2d_constant_let)[cse_var_7])) << ((int64_t)0)) : ((int64_t)((((int32_t*)conv_let)[(((ax3_inner_2 * 3) + ax1_inner_2) + 42)] + ((int32_t*)fused_nn_conv2d_subtract_constant_let)[cse_var_7]) - ((int32_t*)fused_nn_conv2d_constant_let)[cse_var_7]))) * (int64_t)2002065659) + ((int64_t)1 << ((int64_t)((9 + 31) - 1)))) >> ((int64_t)(9 + 31)));
            int32_t v__5 = (v__4) < (255) ? (v__4) : (255);
            T_cast[((((((ax1_outer * 2352) + (ax1_inner_2 * 784)) + (ax2_outer * 112)) + (ax3_outer * 7)) + ax3_inner_2) + 56)] = ((uint8_t)((v__5) > (0) ? (v__5) : (0)));
          }
        }
        for (int32_t ax3_inner_3 = 0; ax3_inner_3 < 7; ++ax3_inner_3) {
          for (int32_t ax1_inner_3 = 0; ax1_inner_3 < 3; ++ax1_inner_3) {
            int32_t cse_var_8 = ((ax1_outer * 3) + ax1_inner_3);
            int32_t v__6 = (int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)conv_let)[(((ax3_inner_3 * 3) + ax1_inner_3) + 63)] + ((int32_t*)fused_nn_conv2d_subtract_constant_let)[cse_var_8]) - ((int32_t*)fused_nn_conv2d_constant_let)[cse_var_8])) << ((int64_t)0)) : ((int64_t)((((int32_t*)conv_let)[(((ax3_inner_3 * 3) + ax1_inner_3) + 63)] + ((int32_t*)fused_nn_conv2d_subtract_constant_let)[cse_var_8]) - ((int32_t*)fused_nn_conv2d_constant_let)[cse_var_8]))) * (int64_t)2002065659) + ((int64_t)1 << ((int64_t)((9 + 31) - 1)))) >> ((int64_t)(9 + 31)));
            int32_t v__7 = (v__6) < (255) ? (v__6) : (255);
            T_cast[((((((ax1_outer * 2352) + (ax1_inner_3 * 784)) + (ax2_outer * 112)) + (ax3_outer * 7)) + ax3_inner_3) + 84)] = ((uint8_t)((v__7) > (0) ? (v__7) : (0)));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_clip_cast_1(int8_t* p0, uint8_t* T_cast, uint8_t* global_const_workspace_8_var, uint8_t* global_workspace_9_var) {
  void* fused_nn_conv2d_constant_1_let = (&(global_const_workspace_8_var[62848]));
  void* fused_nn_conv2d_subtract_constant_1_let = (&(global_const_workspace_8_var[62784]));
  void* fused_constant_1_let = (&(global_const_workspace_8_var[58080]));
  void* data_vec_let = (&(global_workspace_9_var[0]));
  for (int32_t h = 0; h < 5; ++h) {
    for (int32_t w = 0; w < 5; ++w) {
      for (int32_t ci = 0; ci < 6; ++ci) {
        for (int32_t vh = 0; vh < 6; ++vh) {
          for (int32_t vw = 0; vw < 6; ++vw) {
            ((int8_t*)data_vec_let)[(((((h * 1080) + (w * 216)) + (ci * 36)) + (vh * 6)) + vw)] = p0[(((((ci * 196) + (h * 28)) + (vh * 14)) + (w * 2)) + vw)];
          }
        }
      }
    }
  }
  for (int32_t ax1_outer = 0; ax1_outer < 4; ++ax1_outer) {
    void* conv_let = (&(global_workspace_9_var[7000]));
    for (int32_t ax2_outer = 0; ax2_outer < 5; ++ax2_outer) {
      for (int32_t ax3_outer = 0; ax3_outer < 5; ++ax3_outer) {
        for (int32_t vc_init = 0; vc_init < 4; ++vc_init) {
          for (int32_t vw_init = 0; vw_init < 2; ++vw_init) {
            ((int32_t*)conv_let)[((vw_init * 4) + vc_init)] = 0;
          }
          for (int32_t vw_init_1 = 0; vw_init_1 < 2; ++vw_init_1) {
            ((int32_t*)conv_let)[(((vw_init_1 * 4) + vc_init) + 8)] = 0;
          }
        }
        for (int32_t ci_1 = 0; ci_1 < 6; ++ci_1) {
          for (int32_t vc = 0; vc < 4; ++vc) {
            for (int32_t vw_1 = 0; vw_1 < 2; ++vw_1) {
              int32_t cse_var_1 = ((vw_1 * 4) + vc);
              ((int32_t*)conv_let)[cse_var_1] = (((int32_t*)conv_let)[cse_var_1] + (((int32_t)((int8_t*)data_vec_let)[((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_1)]) * ((int32_t)((int8_t*)fused_constant_1_let)[(((ax1_outer * 600) + (ci_1 * 100)) + vc)])));
            }
            for (int32_t vw_2 = 0; vw_2 < 2; ++vw_2) {
              int32_t cse_var_2 = (((vw_2 * 4) + vc) + 8);
              ((int32_t*)conv_let)[cse_var_2] = (((int32_t*)conv_let)[cse_var_2] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_2) + 6)]) * ((int32_t)((int8_t*)fused_constant_1_let)[(((ax1_outer * 600) + (ci_1 * 100)) + vc)])));
            }
          }
          for (int32_t vc_1 = 0; vc_1 < 4; ++vc_1) {
            for (int32_t vw_3 = 0; vw_3 < 2; ++vw_3) {
              int32_t cse_var_3 = ((vw_3 * 4) + vc_1);
              ((int32_t*)conv_let)[cse_var_3] = (((int32_t*)conv_let)[cse_var_3] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_3) + 1)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_1) + 4)])));
            }
            for (int32_t vw_4 = 0; vw_4 < 2; ++vw_4) {
              int32_t cse_var_4 = (((vw_4 * 4) + vc_1) + 8);
              ((int32_t*)conv_let)[cse_var_4] = (((int32_t*)conv_let)[cse_var_4] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_4) + 7)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_1) + 4)])));
            }
          }
          for (int32_t vc_2 = 0; vc_2 < 4; ++vc_2) {
            for (int32_t vw_5 = 0; vw_5 < 2; ++vw_5) {
              int32_t cse_var_5 = ((vw_5 * 4) + vc_2);
              ((int32_t*)conv_let)[cse_var_5] = (((int32_t*)conv_let)[cse_var_5] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_5) + 2)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_2) + 8)])));
            }
            for (int32_t vw_6 = 0; vw_6 < 2; ++vw_6) {
              int32_t cse_var_6 = (((vw_6 * 4) + vc_2) + 8);
              ((int32_t*)conv_let)[cse_var_6] = (((int32_t*)conv_let)[cse_var_6] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_6) + 8)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_2) + 8)])));
            }
          }
          for (int32_t vc_3 = 0; vc_3 < 4; ++vc_3) {
            for (int32_t vw_7 = 0; vw_7 < 2; ++vw_7) {
              int32_t cse_var_7 = ((vw_7 * 4) + vc_3);
              ((int32_t*)conv_let)[cse_var_7] = (((int32_t*)conv_let)[cse_var_7] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_7) + 3)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_3) + 12)])));
            }
            for (int32_t vw_8 = 0; vw_8 < 2; ++vw_8) {
              int32_t cse_var_8 = (((vw_8 * 4) + vc_3) + 8);
              ((int32_t*)conv_let)[cse_var_8] = (((int32_t*)conv_let)[cse_var_8] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_8) + 9)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_3) + 12)])));
            }
          }
          for (int32_t vc_4 = 0; vc_4 < 4; ++vc_4) {
            for (int32_t vw_9 = 0; vw_9 < 2; ++vw_9) {
              int32_t cse_var_9 = ((vw_9 * 4) + vc_4);
              ((int32_t*)conv_let)[cse_var_9] = (((int32_t*)conv_let)[cse_var_9] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_9) + 4)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_4) + 16)])));
            }
            for (int32_t vw_10 = 0; vw_10 < 2; ++vw_10) {
              int32_t cse_var_10 = (((vw_10 * 4) + vc_4) + 8);
              ((int32_t*)conv_let)[cse_var_10] = (((int32_t*)conv_let)[cse_var_10] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_10) + 10)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_4) + 16)])));
            }
          }
          for (int32_t vc_5 = 0; vc_5 < 4; ++vc_5) {
            for (int32_t vw_11 = 0; vw_11 < 2; ++vw_11) {
              int32_t cse_var_11 = ((vw_11 * 4) + vc_5);
              ((int32_t*)conv_let)[cse_var_11] = (((int32_t*)conv_let)[cse_var_11] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_11) + 6)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_5) + 20)])));
            }
            for (int32_t vw_12 = 0; vw_12 < 2; ++vw_12) {
              int32_t cse_var_12 = (((vw_12 * 4) + vc_5) + 8);
              ((int32_t*)conv_let)[cse_var_12] = (((int32_t*)conv_let)[cse_var_12] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_12) + 12)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_5) + 20)])));
            }
          }
          for (int32_t vc_6 = 0; vc_6 < 4; ++vc_6) {
            for (int32_t vw_13 = 0; vw_13 < 2; ++vw_13) {
              int32_t cse_var_13 = ((vw_13 * 4) + vc_6);
              ((int32_t*)conv_let)[cse_var_13] = (((int32_t*)conv_let)[cse_var_13] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_13) + 7)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_6) + 24)])));
            }
            for (int32_t vw_14 = 0; vw_14 < 2; ++vw_14) {
              int32_t cse_var_14 = (((vw_14 * 4) + vc_6) + 8);
              ((int32_t*)conv_let)[cse_var_14] = (((int32_t*)conv_let)[cse_var_14] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_14) + 13)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_6) + 24)])));
            }
          }
          for (int32_t vc_7 = 0; vc_7 < 4; ++vc_7) {
            for (int32_t vw_15 = 0; vw_15 < 2; ++vw_15) {
              int32_t cse_var_15 = ((vw_15 * 4) + vc_7);
              ((int32_t*)conv_let)[cse_var_15] = (((int32_t*)conv_let)[cse_var_15] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_15) + 8)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_7) + 28)])));
            }
            for (int32_t vw_16 = 0; vw_16 < 2; ++vw_16) {
              int32_t cse_var_16 = (((vw_16 * 4) + vc_7) + 8);
              ((int32_t*)conv_let)[cse_var_16] = (((int32_t*)conv_let)[cse_var_16] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_16) + 14)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_7) + 28)])));
            }
          }
          for (int32_t vc_8 = 0; vc_8 < 4; ++vc_8) {
            for (int32_t vw_17 = 0; vw_17 < 2; ++vw_17) {
              int32_t cse_var_17 = ((vw_17 * 4) + vc_8);
              ((int32_t*)conv_let)[cse_var_17] = (((int32_t*)conv_let)[cse_var_17] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_17) + 9)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_8) + 32)])));
            }
            for (int32_t vw_18 = 0; vw_18 < 2; ++vw_18) {
              int32_t cse_var_18 = (((vw_18 * 4) + vc_8) + 8);
              ((int32_t*)conv_let)[cse_var_18] = (((int32_t*)conv_let)[cse_var_18] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_18) + 15)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_8) + 32)])));
            }
          }
          for (int32_t vc_9 = 0; vc_9 < 4; ++vc_9) {
            for (int32_t vw_19 = 0; vw_19 < 2; ++vw_19) {
              int32_t cse_var_19 = ((vw_19 * 4) + vc_9);
              ((int32_t*)conv_let)[cse_var_19] = (((int32_t*)conv_let)[cse_var_19] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_19) + 10)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_9) + 36)])));
            }
            for (int32_t vw_20 = 0; vw_20 < 2; ++vw_20) {
              int32_t cse_var_20 = (((vw_20 * 4) + vc_9) + 8);
              ((int32_t*)conv_let)[cse_var_20] = (((int32_t*)conv_let)[cse_var_20] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_20) + 16)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_9) + 36)])));
            }
          }
          for (int32_t vc_10 = 0; vc_10 < 4; ++vc_10) {
            for (int32_t vw_21 = 0; vw_21 < 2; ++vw_21) {
              int32_t cse_var_21 = ((vw_21 * 4) + vc_10);
              ((int32_t*)conv_let)[cse_var_21] = (((int32_t*)conv_let)[cse_var_21] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_21) + 12)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_10) + 40)])));
            }
            for (int32_t vw_22 = 0; vw_22 < 2; ++vw_22) {
              int32_t cse_var_22 = (((vw_22 * 4) + vc_10) + 8);
              ((int32_t*)conv_let)[cse_var_22] = (((int32_t*)conv_let)[cse_var_22] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_22) + 18)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_10) + 40)])));
            }
          }
          for (int32_t vc_11 = 0; vc_11 < 4; ++vc_11) {
            for (int32_t vw_23 = 0; vw_23 < 2; ++vw_23) {
              int32_t cse_var_23 = ((vw_23 * 4) + vc_11);
              ((int32_t*)conv_let)[cse_var_23] = (((int32_t*)conv_let)[cse_var_23] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_23) + 13)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_11) + 44)])));
            }
            for (int32_t vw_24 = 0; vw_24 < 2; ++vw_24) {
              int32_t cse_var_24 = (((vw_24 * 4) + vc_11) + 8);
              ((int32_t*)conv_let)[cse_var_24] = (((int32_t*)conv_let)[cse_var_24] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_24) + 19)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_11) + 44)])));
            }
          }
          for (int32_t vc_12 = 0; vc_12 < 4; ++vc_12) {
            for (int32_t vw_25 = 0; vw_25 < 2; ++vw_25) {
              int32_t cse_var_25 = ((vw_25 * 4) + vc_12);
              ((int32_t*)conv_let)[cse_var_25] = (((int32_t*)conv_let)[cse_var_25] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_25) + 14)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_12) + 48)])));
            }
            for (int32_t vw_26 = 0; vw_26 < 2; ++vw_26) {
              int32_t cse_var_26 = (((vw_26 * 4) + vc_12) + 8);
              ((int32_t*)conv_let)[cse_var_26] = (((int32_t*)conv_let)[cse_var_26] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_26) + 20)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_12) + 48)])));
            }
          }
          for (int32_t vc_13 = 0; vc_13 < 4; ++vc_13) {
            for (int32_t vw_27 = 0; vw_27 < 2; ++vw_27) {
              int32_t cse_var_27 = ((vw_27 * 4) + vc_13);
              ((int32_t*)conv_let)[cse_var_27] = (((int32_t*)conv_let)[cse_var_27] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_27) + 15)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_13) + 52)])));
            }
            for (int32_t vw_28 = 0; vw_28 < 2; ++vw_28) {
              int32_t cse_var_28 = (((vw_28 * 4) + vc_13) + 8);
              ((int32_t*)conv_let)[cse_var_28] = (((int32_t*)conv_let)[cse_var_28] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_28) + 21)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_13) + 52)])));
            }
          }
          for (int32_t vc_14 = 0; vc_14 < 4; ++vc_14) {
            for (int32_t vw_29 = 0; vw_29 < 2; ++vw_29) {
              int32_t cse_var_29 = ((vw_29 * 4) + vc_14);
              ((int32_t*)conv_let)[cse_var_29] = (((int32_t*)conv_let)[cse_var_29] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_29) + 16)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_14) + 56)])));
            }
            for (int32_t vw_30 = 0; vw_30 < 2; ++vw_30) {
              int32_t cse_var_30 = (((vw_30 * 4) + vc_14) + 8);
              ((int32_t*)conv_let)[cse_var_30] = (((int32_t*)conv_let)[cse_var_30] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_30) + 22)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_14) + 56)])));
            }
          }
          for (int32_t vc_15 = 0; vc_15 < 4; ++vc_15) {
            for (int32_t vw_31 = 0; vw_31 < 2; ++vw_31) {
              int32_t cse_var_31 = ((vw_31 * 4) + vc_15);
              ((int32_t*)conv_let)[cse_var_31] = (((int32_t*)conv_let)[cse_var_31] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_31) + 18)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_15) + 60)])));
            }
            for (int32_t vw_32 = 0; vw_32 < 2; ++vw_32) {
              int32_t cse_var_32 = (((vw_32 * 4) + vc_15) + 8);
              ((int32_t*)conv_let)[cse_var_32] = (((int32_t*)conv_let)[cse_var_32] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_32) + 24)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_15) + 60)])));
            }
          }
          for (int32_t vc_16 = 0; vc_16 < 4; ++vc_16) {
            for (int32_t vw_33 = 0; vw_33 < 2; ++vw_33) {
              int32_t cse_var_33 = ((vw_33 * 4) + vc_16);
              ((int32_t*)conv_let)[cse_var_33] = (((int32_t*)conv_let)[cse_var_33] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_33) + 19)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_16) + 64)])));
            }
            for (int32_t vw_34 = 0; vw_34 < 2; ++vw_34) {
              int32_t cse_var_34 = (((vw_34 * 4) + vc_16) + 8);
              ((int32_t*)conv_let)[cse_var_34] = (((int32_t*)conv_let)[cse_var_34] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_34) + 25)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_16) + 64)])));
            }
          }
          for (int32_t vc_17 = 0; vc_17 < 4; ++vc_17) {
            for (int32_t vw_35 = 0; vw_35 < 2; ++vw_35) {
              int32_t cse_var_35 = ((vw_35 * 4) + vc_17);
              ((int32_t*)conv_let)[cse_var_35] = (((int32_t*)conv_let)[cse_var_35] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_35) + 20)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_17) + 68)])));
            }
            for (int32_t vw_36 = 0; vw_36 < 2; ++vw_36) {
              int32_t cse_var_36 = (((vw_36 * 4) + vc_17) + 8);
              ((int32_t*)conv_let)[cse_var_36] = (((int32_t*)conv_let)[cse_var_36] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_36) + 26)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_17) + 68)])));
            }
          }
          for (int32_t vc_18 = 0; vc_18 < 4; ++vc_18) {
            for (int32_t vw_37 = 0; vw_37 < 2; ++vw_37) {
              int32_t cse_var_37 = ((vw_37 * 4) + vc_18);
              ((int32_t*)conv_let)[cse_var_37] = (((int32_t*)conv_let)[cse_var_37] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_37) + 21)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_18) + 72)])));
            }
            for (int32_t vw_38 = 0; vw_38 < 2; ++vw_38) {
              int32_t cse_var_38 = (((vw_38 * 4) + vc_18) + 8);
              ((int32_t*)conv_let)[cse_var_38] = (((int32_t*)conv_let)[cse_var_38] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_38) + 27)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_18) + 72)])));
            }
          }
          for (int32_t vc_19 = 0; vc_19 < 4; ++vc_19) {
            for (int32_t vw_39 = 0; vw_39 < 2; ++vw_39) {
              int32_t cse_var_39 = ((vw_39 * 4) + vc_19);
              ((int32_t*)conv_let)[cse_var_39] = (((int32_t*)conv_let)[cse_var_39] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_39) + 22)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_19) + 76)])));
            }
            for (int32_t vw_40 = 0; vw_40 < 2; ++vw_40) {
              int32_t cse_var_40 = (((vw_40 * 4) + vc_19) + 8);
              ((int32_t*)conv_let)[cse_var_40] = (((int32_t*)conv_let)[cse_var_40] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_40) + 28)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_19) + 76)])));
            }
          }
          for (int32_t vc_20 = 0; vc_20 < 4; ++vc_20) {
            for (int32_t vw_41 = 0; vw_41 < 2; ++vw_41) {
              int32_t cse_var_41 = ((vw_41 * 4) + vc_20);
              ((int32_t*)conv_let)[cse_var_41] = (((int32_t*)conv_let)[cse_var_41] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_41) + 24)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_20) + 80)])));
            }
            for (int32_t vw_42 = 0; vw_42 < 2; ++vw_42) {
              int32_t cse_var_42 = (((vw_42 * 4) + vc_20) + 8);
              ((int32_t*)conv_let)[cse_var_42] = (((int32_t*)conv_let)[cse_var_42] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_42) + 30)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_20) + 80)])));
            }
          }
          for (int32_t vc_21 = 0; vc_21 < 4; ++vc_21) {
            for (int32_t vw_43 = 0; vw_43 < 2; ++vw_43) {
              int32_t cse_var_43 = ((vw_43 * 4) + vc_21);
              ((int32_t*)conv_let)[cse_var_43] = (((int32_t*)conv_let)[cse_var_43] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_43) + 25)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_21) + 84)])));
            }
            for (int32_t vw_44 = 0; vw_44 < 2; ++vw_44) {
              int32_t cse_var_44 = (((vw_44 * 4) + vc_21) + 8);
              ((int32_t*)conv_let)[cse_var_44] = (((int32_t*)conv_let)[cse_var_44] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_44) + 31)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_21) + 84)])));
            }
          }
          for (int32_t vc_22 = 0; vc_22 < 4; ++vc_22) {
            for (int32_t vw_45 = 0; vw_45 < 2; ++vw_45) {
              int32_t cse_var_45 = ((vw_45 * 4) + vc_22);
              ((int32_t*)conv_let)[cse_var_45] = (((int32_t*)conv_let)[cse_var_45] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_45) + 26)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_22) + 88)])));
            }
            for (int32_t vw_46 = 0; vw_46 < 2; ++vw_46) {
              int32_t cse_var_46 = (((vw_46 * 4) + vc_22) + 8);
              ((int32_t*)conv_let)[cse_var_46] = (((int32_t*)conv_let)[cse_var_46] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_46) + 32)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_22) + 88)])));
            }
          }
          for (int32_t vc_23 = 0; vc_23 < 4; ++vc_23) {
            for (int32_t vw_47 = 0; vw_47 < 2; ++vw_47) {
              int32_t cse_var_47 = ((vw_47 * 4) + vc_23);
              ((int32_t*)conv_let)[cse_var_47] = (((int32_t*)conv_let)[cse_var_47] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_47) + 27)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_23) + 92)])));
            }
            for (int32_t vw_48 = 0; vw_48 < 2; ++vw_48) {
              int32_t cse_var_48 = (((vw_48 * 4) + vc_23) + 8);
              ((int32_t*)conv_let)[cse_var_48] = (((int32_t*)conv_let)[cse_var_48] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_48) + 33)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_23) + 92)])));
            }
          }
          for (int32_t vc_24 = 0; vc_24 < 4; ++vc_24) {
            for (int32_t vw_49 = 0; vw_49 < 2; ++vw_49) {
              int32_t cse_var_49 = ((vw_49 * 4) + vc_24);
              ((int32_t*)conv_let)[cse_var_49] = (((int32_t*)conv_let)[cse_var_49] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_49) + 28)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_24) + 96)])));
            }
            for (int32_t vw_50 = 0; vw_50 < 2; ++vw_50) {
              int32_t cse_var_50 = (((vw_50 * 4) + vc_24) + 8);
              ((int32_t*)conv_let)[cse_var_50] = (((int32_t*)conv_let)[cse_var_50] + (((int32_t)((int8_t*)data_vec_let)[(((((ax2_outer * 1080) + (ax3_outer * 216)) + (ci_1 * 36)) + vw_50) + 34)]) * ((int32_t)((int8_t*)fused_constant_1_let)[((((ax1_outer * 600) + (ci_1 * 100)) + vc_24) + 96)])));
            }
          }
        }
        for (int32_t ax3_inner = 0; ax3_inner < 2; ++ax3_inner) {
          for (int32_t ax1_inner = 0; ax1_inner < 4; ++ax1_inner) {
            int32_t cse_var_51 = ((ax1_outer * 4) + ax1_inner);
            int32_t v_ = (int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)conv_let)[((ax3_inner * 4) + ax1_inner)] + ((int32_t*)fused_nn_conv2d_subtract_constant_1_let)[cse_var_51]) - ((int32_t*)fused_nn_conv2d_constant_1_let)[cse_var_51])) << ((int64_t)0)) : ((int64_t)((((int32_t*)conv_let)[((ax3_inner * 4) + ax1_inner)] + ((int32_t*)fused_nn_conv2d_subtract_constant_1_let)[cse_var_51]) - ((int32_t*)fused_nn_conv2d_constant_1_let)[cse_var_51]))) * (int64_t)1708059235) + ((int64_t)1 << ((int64_t)((8 + 31) - 1)))) >> ((int64_t)(8 + 31)));
            int32_t v__1 = (v_) < (255) ? (v_) : (255);
            T_cast[(((((ax1_outer * 400) + (ax1_inner * 100)) + (ax2_outer * 20)) + (ax3_outer * 2)) + ax3_inner)] = ((uint8_t)((v__1) > (0) ? (v__1) : (0)));
          }
        }
        for (int32_t ax3_inner_1 = 0; ax3_inner_1 < 2; ++ax3_inner_1) {
          for (int32_t ax1_inner_1 = 0; ax1_inner_1 < 4; ++ax1_inner_1) {
            int32_t cse_var_52 = ((ax1_outer * 4) + ax1_inner_1);
            int32_t v__2 = (int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)conv_let)[(((ax3_inner_1 * 4) + ax1_inner_1) + 8)] + ((int32_t*)fused_nn_conv2d_subtract_constant_1_let)[cse_var_52]) - ((int32_t*)fused_nn_conv2d_constant_1_let)[cse_var_52])) << ((int64_t)0)) : ((int64_t)((((int32_t*)conv_let)[(((ax3_inner_1 * 4) + ax1_inner_1) + 8)] + ((int32_t*)fused_nn_conv2d_subtract_constant_1_let)[cse_var_52]) - ((int32_t*)fused_nn_conv2d_constant_1_let)[cse_var_52]))) * (int64_t)1708059235) + ((int64_t)1 << ((int64_t)((8 + 31) - 1)))) >> ((int64_t)(8 + 31)));
            int32_t v__3 = (v__2) < (255) ? (v__2) : (255);
            T_cast[((((((ax1_outer * 400) + (ax1_inner_1 * 100)) + (ax2_outer * 20)) + (ax3_outer * 2)) + ax3_inner_1) + 10)] = ((uint8_t)((v__3) > (0) ? (v__3) : (0)));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_dense_add_fixed_point_multiply_clip_add_cast(int8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_16_var, uint8_t* global_workspace_17_var) {
  void* fused_nn_dense_constant_let = (&(global_const_workspace_16_var[62288]));
  void* fused_constant_3_let = (&(global_const_workspace_16_var[48000]));
  void* dense_let = (&(global_workspace_17_var[0]));
  for (int32_t y_outer = 0; y_outer < 84; ++y_outer) {
    gemm_1x1x1_reset_XDPGNFLF((&(((int32_t*)dense_let)[y_outer])), 1);
    for (int32_t k_outer = 0; k_outer < 120; ++k_outer) {
      gemm_1x1x1_update_XDPGNFLF((&(p0[k_outer])), (&(((int8_t*)fused_constant_3_let)[((y_outer * 120) + k_outer)])), (&(((int32_t*)dense_let)[y_outer])), 1, 1, 1);
    }
  }
  for (int32_t ax1 = 0; ax1 < 84; ++ax1) {
    int32_t v_ = (int32_t)(((((0 != 0) ? (((int64_t)(((int32_t*)dense_let)[ax1] + ((int32_t*)fused_nn_dense_constant_let)[ax1])) << ((int64_t)0)) : ((int64_t)(((int32_t*)dense_let)[ax1] + ((int32_t*)fused_nn_dense_constant_let)[ax1]))) * (int64_t)1902855126) + ((int64_t)1 << ((int64_t)((9 + 31) - 1)))) >> ((int64_t)(9 + 31)));
    int32_t v__1 = (v_) < (255) ? (v_) : (255);
    T_cast[ax1] = ((int8_t)(((v__1) > (0) ? (v__1) : (0)) - 128));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_dense_subtract_add_fixed_point_multiply_add_clip_subtract_cast_multiply(int8_t* p0, float* T_multiply, uint8_t* global_const_workspace_18_var, uint8_t* global_workspace_19_var) {
  void* fused_nn_dense_constant_1_let = (&(global_const_workspace_18_var[62960]));
  void* fused_nn_dense_subtract_constant_let = (&(global_const_workspace_18_var[62912]));
  void* fused_constant_4_let = (&(global_const_workspace_18_var[60480]));
  void* dense_let = (&(global_workspace_19_var[420]));
  for (int32_t y_outer = 0; y_outer < 10; ++y_outer) {
    gemm_1x1x1_reset_BNVCGIOM((&(((int32_t*)dense_let)[y_outer])), 1);
    for (int32_t k_outer = 0; k_outer < 84; ++k_outer) {
      gemm_1x1x1_update_BNVCGIOM((&(p0[k_outer])), (&(((int8_t*)fused_constant_4_let)[((y_outer * 84) + k_outer)])), (&(((int32_t*)dense_let)[y_outer])), 1, 1, 1);
    }
  }
  for (int32_t ax1 = 0; ax1 < 10; ++ax1) {
    int32_t v_ = ((int32_t)(((((0 != 0) ? (((int64_t)((((int32_t*)dense_let)[ax1] + ((int32_t*)fused_nn_dense_subtract_constant_let)[ax1]) - ((int32_t*)fused_nn_dense_constant_1_let)[ax1])) << ((int64_t)0)) : ((int64_t)((((int32_t*)dense_let)[ax1] + ((int32_t*)fused_nn_dense_subtract_constant_let)[ax1]) - ((int32_t*)fused_nn_dense_constant_1_let)[ax1]))) * (int64_t)1207605655) + ((int64_t)1 << ((int64_t)((9 + 31) - 1)))) >> ((int64_t)(9 + 31)))) + 173;
    int32_t v__1 = (v_) < (255) ? (v_) : (255);
    T_multiply[ax1] = (((float)(((v__1) > (0) ? (v__1) : (0)) - 173)) * 2.699091e-01f);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_log_softmax(float* p0, float* compute, uint8_t* global_const_workspace_20_var, uint8_t* global_workspace_21_var) {
  void* T_softmax_maxelem_let = (&(global_workspace_21_var[44]));
  void* compute_let = (&(global_workspace_21_var[40]));
  ((float*)T_softmax_maxelem_let)[0] = -3.402823e+38f;
  for (int32_t k = 0; k < 10; ++k) {
    float v_ = ((float*)T_softmax_maxelem_let)[0];
    float v__1 = p0[k];
    ((float*)T_softmax_maxelem_let)[0] = ((v_) > (v__1) ? (v_) : (v__1));
  }
  ((float*)compute_let)[0] = 0.000000e+00f;
  for (int32_t k_1 = 0; k_1 < 10; ++k_1) {
    ((float*)compute_let)[0] = (((float*)compute_let)[0] + expf((p0[k_1] - ((float*)T_softmax_maxelem_let)[0])));
  }
  for (int32_t i1 = 0; i1 < 10; ++i1) {
    compute[i1] = ((p0[i1] - ((float*)T_softmax_maxelem_let)[0]) - logf(((float*)compute_let)[0]));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_max_pool2d_cast_add_cast(uint8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_6_var, uint8_t* global_workspace_7_var) {
  void* pool_max_let = (&(global_workspace_7_var[6576]));
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 6; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 14; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 14; ++ax3) {
        ((uint8_t*)pool_max_let)[(((ax0_ax1_fused * 196) + (ax2 * 14)) + ax3)] = (uint8_t)0;
        for (int32_t rv0 = 0; rv0 < 2; ++rv0) {
          for (int32_t rv1 = 0; rv1 < 2; ++rv1) {
            int32_t cse_var_1 = (((ax0_ax1_fused * 196) + (ax2 * 14)) + ax3);
            uint8_t v_ = ((uint8_t*)pool_max_let)[cse_var_1];
            uint8_t v__1 = p0[(((((ax0_ax1_fused * 784) + (ax2 * 56)) + (rv0 * 28)) + (ax3 * 2)) + rv1)];
            ((uint8_t*)pool_max_let)[cse_var_1] = ((v_) > (v__1) ? (v_) : (v__1));
          }
        }
      }
    }
  }
  for (int32_t ax0_ax1_fused_1 = 0; ax0_ax1_fused_1 < 6; ++ax0_ax1_fused_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 14; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 14; ++ax3_1) {
        int32_t cse_var_2 = (((ax0_ax1_fused_1 * 196) + (ax2_1 * 14)) + ax3_1);
        T_cast[cse_var_2] = ((int8_t)(((int32_t)((uint8_t*)pool_max_let)[cse_var_2]) - 128));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_max_pool2d_cast_add_cast_1(uint8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_10_var, uint8_t* global_workspace_11_var) {
  void* pool_max_let = (&(global_workspace_11_var[7000]));
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 16; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 5; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 5; ++ax3) {
        ((uint8_t*)pool_max_let)[(((ax0_ax1_fused * 25) + (ax2 * 5)) + ax3)] = (uint8_t)0;
        for (int32_t rv0 = 0; rv0 < 2; ++rv0) {
          for (int32_t rv1 = 0; rv1 < 2; ++rv1) {
            int32_t cse_var_1 = (((ax0_ax1_fused * 25) + (ax2 * 5)) + ax3);
            uint8_t v_ = ((uint8_t*)pool_max_let)[cse_var_1];
            uint8_t v__1 = p0[(((((ax0_ax1_fused * 100) + (ax2 * 20)) + (rv0 * 10)) + (ax3 * 2)) + rv1)];
            ((uint8_t*)pool_max_let)[cse_var_1] = ((v_) > (v__1) ? (v_) : (v__1));
          }
        }
      }
    }
  }
  for (int32_t ax0_ax1_fused_1 = 0; ax0_ax1_fused_1 < 16; ++ax0_ax1_fused_1) {
    for (int32_t ax2_1 = 0; ax2_1 < 5; ++ax2_1) {
      for (int32_t ax3_1 = 0; ax3_1 < 5; ++ax3_1) {
        int32_t cse_var_2 = (((ax0_ax1_fused_1 * 25) + (ax2_1 * 5)) + ax3_1);
        T_cast[cse_var_2] = ((int8_t)(((int32_t)((uint8_t*)pool_max_let)[cse_var_2]) - 128));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_reshape_squeeze_cast_add_cast(uint8_t* p0, int8_t* T_cast, uint8_t* global_const_workspace_14_var, uint8_t* global_workspace_15_var) {
  for (int32_t ax1_outer = 0; ax1_outer < 8; ++ax1_outer) {
    for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
      if (((ax1_outer * 2) + (ax1_inner >> 3)) < 15) {
        int32_t cse_var_1 = ((ax1_outer * 16) + ax1_inner);
        T_cast[cse_var_1] = ((int8_t)(((int32_t)p0[cse_var_1]) - 128));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* input0_buffer_var, float* output_buffer_var, uint8_t* global_const_workspace_0_var, uint8_t* global_workspace_1_var) {
  void* sid_9_let = (&(global_workspace_1_var[0]));
  void* sid_4_let = (&(global_workspace_1_var[5400]));
  void* sid_3_let = (&(global_workspace_1_var[5400]));
  void* sid_5_let = (&(global_workspace_1_var[400]));
  void* sid_6_let = (&(global_workspace_1_var[400]));
  void* sid_2_let = (&(global_workspace_1_var[0]));
  void* sid_1_let = (&(global_workspace_1_var[7168]));
  void* sid_7_let = (&(global_workspace_1_var[520]));
  void* sid_8_let = (&(global_workspace_1_var[336]));
  if (tvmgen_default_fused_divide_round_add_clip_cast_nn_pad_cast_add_cast(input0_buffer_var, sid_1_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_clip_cast(sid_1_let, sid_2_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_max_pool2d_cast_add_cast(sid_2_let, sid_3_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_clip_cast_1(sid_3_let, sid_4_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_max_pool2d_cast_add_cast_1(sid_4_let, sid_5_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_conv2d_subtract_add_fixed_point_multiply_add_clip_cast(sid_5_let, sid_6_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_reshape_squeeze_cast_add_cast(sid_6_let, sid_7_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_dense_add_fixed_point_multiply_clip_add_cast(sid_7_let, sid_8_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_dense_subtract_add_fixed_point_multiply_add_clip_subtract_cast_multiply(sid_8_let, sid_9_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_log_softmax(sid_9_let, output_buffer_var, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  return 0;
}

